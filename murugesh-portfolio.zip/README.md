# Murugesh Portfolio
Upload `index.html` and `style.css` to the root of your GitHub repository.
Then open **Settings → Pages → Deploy from a branch → main → / (root)** and Save.
